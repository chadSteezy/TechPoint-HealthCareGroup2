//
//  UnIDApp.swift
//  UnID
//
//  Created by Keegan Briskey on 7/2/21.
//

import SwiftUI

@main
struct UnIDApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
