//
//  SignInView.swift
//  UnID
//
//  Created by Keegan Briskey on 7/6/21.
//

import SwiftUI

struct SignInView: View {
    var body: some View {
        NavigationView {
            
            VStack {
                Image("logo")
                    .frame(width: 150.0, height: 100.0)
                    .padding(.top, -40.0)
                
                Text("Sign In")
                    .font(.largeTitle)
                    .fontWeight(.regular)
                    .padding(.top, 50.0)
                    .padding(.bottom, 30.0)
                
                VStack {
                    
                    //input field for email
                    HStack {
                        Image(systemName: "person.fill")
                            .padding(.leading, 7.0)
                        
                        
                        TextField("Email", text: .constant(""))
                            .foregroundColor(.blue)
                        
                    }
                    .frame(width: 300.0, height: 50.0)
                    .overlay(
                        RoundedRectangle(cornerRadius: 7)
                            .stroke(Color.gray,
                                    lineWidth: 2.5)
                    )
                    .padding(.bottom, 30.0)
                    
                    
                    //input field for password
                    HStack {
                        Image(systemName: "key.fill")
                            .padding(.leading, 7.0)
                        
                        
                        TextField("Password", text: .constant(""))
                            .foregroundColor(.blue)
                        
                    }
                    .frame(width: 300.0, height: 50.0)
                    .overlay(
                        RoundedRectangle(cornerRadius: 7)
                            .stroke(Color.gray,
                                    lineWidth: 2.5)
                    )
                    .padding(.bottom, 30.0)
                    
                }
                VStack {
                    NavigationLink(destination: MainView().navigationBarHidden(true)) {
                        Text("Sign In")
                            .font(.headline)
                            .foregroundColor(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0))
                            .multilineTextAlignment(.center)
                            .padding(.all)
                            .frame(width: 90.0, height: 50.0)
                            .overlay(
                                RoundedRectangle(cornerRadius: 5)
                                    .stroke(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0), lineWidth: 2.5)
                            )
                            .padding(.bottom, 70.0)
                    }
                    
                }
                
                VStack(){
                    Text("Dont have an account?")
                    NavigationLink(destination: CreateAccountView()) {
                        Text("Create one here")
                            .foregroundColor(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0))
                    }
                }
                Spacer()
            }
        }
    }
}

struct SignInView_Previews: PreviewProvider {
    static var previews: some View {
        SignInView()
    }
}
