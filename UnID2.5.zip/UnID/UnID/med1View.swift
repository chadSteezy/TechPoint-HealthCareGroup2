//
//  med1View.swift
//  UnID
//
//  Created by Evan on 7/8/21.
//  This is the first viewablee medicine slot

import SwiftUI

struct med1View: View {
    var body: some View {
        Text("refer to wireframe")
        Text("Prescription detail view")
    }
}

struct med1View_Previews: PreviewProvider {
    static var previews: some View {
        med1View()
    }
}
