//
//  CreateAccountView.swift
//  UnID
//
//  Created by Keegan Briskey on 7/7/21.
//

import SwiftUI

// Evan worked here on 7/6/21.
struct CreateAccountView: View {
    var body: some View {
        Image("logo")
            .frame(width: 150.0, height: 100.0)
            .padding(.top, -60.0) //forces the logo to get closer to the top of thee screen
            .padding(.bottom, 10.0)
        
        VStack() {
            
            //input field for First Name
            HStack {
                Image(systemName: "heart.text.sqaure.fill")
                    .padding(.leading, 7.0)
                
                
                TextField("First Name", text: /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Value@*/.constant("")/*@END_MENU_TOKEN@*/)
                    .foregroundColor(.blue)
                
            }
            .frame(width: 300.0, height: 50.0)
            .overlay(
                RoundedRectangle(cornerRadius: 7)
                    .stroke(Color.gray,
                            lineWidth: 2.5)
            )
            .padding(.bottom, 20.0)
            
            //input field for Last Name
            HStack {
                Image(systemName: "heart.text.sqaure.fill")
                    .padding(.leading, 7.0)
                
                
                TextField("Last Name", text: /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Value@*/.constant("")/*@END_MENU_TOKEN@*/)
                    .foregroundColor(.blue)
                
            }
            .frame(width: 300.0, height: 50.0)
            .overlay(
                RoundedRectangle(cornerRadius: 7)
                    .stroke(Color.gray,
                            lineWidth: 2.5)
            )
            .padding(.bottom, 20.0)
            
            //input field for DOB
            HStack {
                Image(systemName: "heart.text.sqaure.fill")
                    .padding(.leading, 7.0)
                
                
                TextField("DOB: MM-DD-YYYY", text: /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Value@*/.constant("")/*@END_MENU_TOKEN@*/)
                    .foregroundColor(.blue)
                
            }
            .frame(width: 300.0, height: 50.0)
            .overlay(
                RoundedRectangle(cornerRadius: 7)
                    .stroke(Color.gray,
                            lineWidth: 2.5)
            )
            .padding(.bottom, 20.0)
            
            //input field for Primary Health Care Provider
            HStack {
                Image(systemName: "heart.text.sqaure.fill")
                    .padding(.leading, 7.0)
                
                
                TextField("Primary Health Care Provider", text: /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Value@*/.constant("")/*@END_MENU_TOKEN@*/)
                    .foregroundColor(.blue)
                
            }
            .frame(width: 300.0, height: 50.0)
            .overlay(
                RoundedRectangle(cornerRadius: 7)
                    .stroke(Color.gray,
                            lineWidth: 2.5)
            )
            .padding(.bottom, 5.0)
        }
        
        //start of next set of text
        Text("Account")
            .font(.title2)
            .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
            .padding(.top, 20.0)
            .padding(.trailing, 215.0)
        
        VStack {
            
            //input field for email
            HStack {
                Image(systemName: "heart.text.sqaure.fill")
                    .padding(.leading, 7.0)
                
                
                TextField("Email", text: /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Value@*/.constant("")/*@END_MENU_TOKEN@*/)
                    .foregroundColor(.blue)
                
            }
            .frame(width: 300.0, height: 50.0)
            .overlay(
                RoundedRectangle(cornerRadius: 7)
                    .stroke(Color.gray,
                            lineWidth: 2.5)
            )
            .padding(.bottom, 20.0)
            
            //input field for password
            HStack {
                Image(systemName: "heart.text.sqaure.fill")
                    .padding(.leading, 7.0)
                
                
                TextField("Password", text: /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Value@*/.constant("")/*@END_MENU_TOKEN@*/)
                    .foregroundColor(.blue)
                
            }
            .frame(width: 300.0, height: 50.0)
            .overlay(
                RoundedRectangle(cornerRadius: 7)
                    .stroke(Color.gray,
                            lineWidth: 2.5)
            )
            .padding(.bottom, 30.0)
            
        }
        VStack {
            NavigationLink(destination: MainView().navigationBarHidden(true)) {
                Text("Create Account")
                    .font(.headline)
                    .foregroundColor(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0))
                    .multilineTextAlignment(.center)
                    .padding(.all)
                    .frame(width: 190.0, height: 50.0)
                    .overlay(
                        RoundedRectangle(cornerRadius: 5)
                            .stroke(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0), lineWidth: 2.5)
                    )
                    .padding(.bottom, 30.0)
            }
        }
    }
}

struct CreateAccountView_Previews: PreviewProvider {
    static var previews: some View {
        CreateAccountView()
    }
}
