//
//  SharingView.swift
//  UnID
//
//  Created by Keegan Briskey on 7/7/21.
//

import SwiftUI

struct SharingView: View {
    var body: some View {
        Text("Sharing Page")
    }
}

struct SharingView_Previews: PreviewProvider {
    static var previews: some View {
        SharingView()
    }
}
