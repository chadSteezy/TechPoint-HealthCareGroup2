//
//  SharingView.swift
//  UnID
//
//  Created by Keegan Briskey on 7/7/21.
//

import SwiftUI

struct SharingView: View {
    
    //not the best practice but okay for the pitch
    @State var toggleIsOn1: Bool = false
    @State var toggleIsOn2: Bool = false
    @State var toggleIsOn3: Bool = false
    @State var toggleIsOn4: Bool = false
    @State var toggleIsOn5: Bool = false
    @State var toggleIsOn6: Bool = false
    @State var toggleIsOn7: Bool = false
    @State var toggleIsOn8: Bool = false
    @State var toggleIsOn9: Bool = false
    
    @State var selection: String = "Community Health Network"
    let filterOptions: [String] = ["Community Health Network", "IUPUI", "Indianapolis MedCheck"
    ]
    
    var body: some View {
        Text("Sharing")
            .font(.largeTitle)
            .fontWeight(.semibold)
            .multilineTextAlignment(.center)
            .padding(.trailing, 250.0)
            .padding(.top, -40.0)
        
        Text("Tap to choose a different organization")
            .font(.subheadline)
            .padding(.trailing, 104.0)
            .padding(.top, -15.0)
            .padding(.bottom, 20.0)
        
        Picker(selection: $selection,
               label:
                HStack {
                    //                    Text("")
                    HStack {
                        Image(systemName: "heart.text.square").font(.system(size: 21))
                        
                        Text(selection)
                            .frame(width: 250.0, height: 55.0)
                    
                    }
                }
                .font(.headline)
                .foregroundColor(.white)
                .padding(.horizontal, 25.0)
                .background(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0))
                .cornerRadius(10)
                .shadow(color: Color.black.opacity(0.3), radius: 10, x:0, y: 10),
               content: {
                ForEach(filterOptions, id: \.self) { option in
                    Text(option)
                        .tag(option)
                }
               })
            .pickerStyle(MenuPickerStyle())
            .padding(.bottom, 15.0)
            .padding(.top, -3.0)
        
        //for the first selection
        if selection == "Community Health Network"{
            VStack {
                HStack {
                NavigationLink(destination: VaccinationDetailView()) {
                    Text("General Information")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .padding(.trailing, 163.0)
                        
                        .foregroundColor(Color(.black))
                        .multilineTextAlignment(.center)
                        .frame(width: 400.0, height: 50.0)
    //                    .background(Color.gray)
                }
    //            Image(systemName: "menubar.arrow.down.rectangle")
    //                .padding(.leading, -50.0)
    //                .font(.system(size: 19))
            }
            .padding(.top, -15.0)
            }
            
            
            VStack {
                NavigationLink(destination: VaccinationDetailView()) {
                    Text("Vaccinations")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .padding(.trailing, 235.0)
                        
                        .foregroundColor(Color(.black))
                        .multilineTextAlignment(.center)
                        .frame(width: 400.0, height: 50.0)
                }
            }
            
            VStack {
                List {
                    HStack {
                        Text("COVID-19 (Pfizer)")
                        Toggle(isOn: $toggleIsOn1) {
                        }
                    }
                    HStack {
                        Text("FLUZONE (Sanofi)")
                        Toggle(isOn: $toggleIsOn2) {
                        }
                    }
                    HStack {
                        Text("PCV13 (Prevnar)")
                        Toggle(isOn: $toggleIsOn3) {
                        }
                    }
                }
            }.padding(.top, -15.0)
        }
        
        //for the 2nd selection
        else if selection == "IUPUI"{
            VStack {
                HStack {
                    
                
                NavigationLink(destination: VaccinationDetailView()) {
                    Text("General Information")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .padding(.trailing, 163.0)
                        
                        .foregroundColor(Color(.black))
                        .multilineTextAlignment(.center)
                        .frame(width: 400.0, height: 50.0)
    //                    .background(Color.gray)
                }
    //            Image(systemName: "menubar.arrow.down.rectangle")
    //                .padding(.leading, -50.0)
    //                .font(.system(size: 19))
            }
            .padding(.top, -15.0)
            }
            
            
            VStack {
                NavigationLink(destination: VaccinationDetailView()) {
                    Text("Vaccinations")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .padding(.trailing, 235.0)
                        
                        .foregroundColor(Color(.black))
                        .multilineTextAlignment(.center)
                        .frame(width: 400.0, height: 50.0)
                }
            }
            
            VStack {
                List {
                    HStack {
                        Text("COVID-19 (Pfizer)")
                        Toggle(isOn: $toggleIsOn4) {
                        }
                    }
                    HStack {
                        Text("FLUZONE (Sanofi)")
                        Toggle(isOn: $toggleIsOn5) {
                        }
                    }
                    HStack {
                        Text("PCV13 (Prevnar)")
                        Toggle(isOn: $toggleIsOn6) {
                        }
                    }
                }
            }.padding(.top, -15.0)        }
        
        //for the final selection
        else{
            VStack {
                HStack {
                    
                
                NavigationLink(destination: VaccinationDetailView()) {
                    Text("General Information")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .padding(.trailing, 163.0)
                        
                        .foregroundColor(Color(.black))
                        .multilineTextAlignment(.center)
                        .frame(width: 400.0, height: 50.0)
    //                    .background(Color.gray)
                }
    //            Image(systemName: "menubar.arrow.down.rectangle")
    //                .padding(.leading, -50.0)
    //                .font(.system(size: 19))
            }
            .padding(.top, -15.0)
            }
            
            
            VStack {
                NavigationLink(destination: VaccinationDetailView()) {
                    Text("Vaccinations")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .padding(.trailing, 235.0)
                        
                        .foregroundColor(Color(.black))
                        .multilineTextAlignment(.center)
                        .frame(width: 400.0, height: 50.0)
                }
            }
            
            VStack {
                List {
                    HStack {
                        Text("COVID-19 (Pfizer)")
                        Toggle(isOn: $toggleIsOn7) {
                        }
                    }
                    HStack {
                        Text("FLUZONE (Sanofi)")
                        Toggle(isOn: $toggleIsOn8) {
                        }
                    }
                    HStack {
                        Text("PCV13 (Prevnar)")
                        Toggle(isOn: $toggleIsOn9) {
                        }
                    }
                }
            }.padding(.top, -15.0)
        }
        //Text(selection) //prints the current selection, not the whole array
        
        Divider()
            .padding(.bottom, 15.0)
        Spacer()
    }
}
    
        //This was the eextra code, leeaving it as a comment
        /*
        VStack {
            HStack {
                
            
            NavigationLink(destination: VaccinationDetailView()) {
                Text("General Information")
                    .font(.title2)
                    .fontWeight(.semibold)
                    .padding(.trailing, 163.0)
                    
                    .foregroundColor(Color(.black))
                    .multilineTextAlignment(.center)
                    .frame(width: 400.0, height: 50.0)
//                    .background(Color.gray)
            }
//            Image(systemName: "menubar.arrow.down.rectangle")
//                .padding(.leading, -50.0)
//                .font(.system(size: 19))
        }
        .padding(.top, -15.0)
        }
        
        
        VStack {
            NavigationLink(destination: VaccinationDetailView()) {
                Text("Vaccinations")
                    .font(.title2)
                    .fontWeight(.semibold)
                    .padding(.trailing, 235.0)
                    
                    .foregroundColor(Color(.black))
                    .multilineTextAlignment(.center)
                    .frame(width: 400.0, height: 50.0)
            }
        }
        
        VStack {
            List {
                HStack {
                    Text("COVID-19 (Pfizer)")
                    Toggle(isOn: /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Is On@*/.constant(true)/*@END_MENU_TOKEN@*/) {
                    }
                }
                HStack {
                    Text("FLUZONE (Sanofi)")
                    Toggle(isOn: /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Is On@*/.constant(true)/*@END_MENU_TOKEN@*/) {
                    }
                }
                HStack {
                    Text("PCV13 (Prevnar)")
                    Toggle(isOn: /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Is On@*/.constant(true)/*@END_MENU_TOKEN@*/) {
                    }
                }
            }
        }.padding(.top, -15.0)
    }
}*/



struct SharingView_Previews: PreviewProvider {
    static var previews: some View {
        SharingView()
    }
}
