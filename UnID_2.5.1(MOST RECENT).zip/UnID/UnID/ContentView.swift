//
//  ContentView.swift
//  UnID
//
//  Created by Keegan Briskey on 7/2/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        SignInView()
    }
}

struct CreateView: View {
    var body: some View {
        Text("Create Account")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
