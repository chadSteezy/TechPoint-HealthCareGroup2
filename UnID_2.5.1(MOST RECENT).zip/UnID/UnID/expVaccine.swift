//
//  expVaccine.swift
//  UnID
//
//  Created by Evan on 7/11/21.
//

//do not know if we need this yet...
import SwiftUI

struct expVaccine: View {
    var body: some View {
        Text("Covid-19")
            .padding(.top, 40.0)
    }
}

struct expVaccine_Previews: PreviewProvider {
    static var previews: some View {
        expVaccine()
    }
}
