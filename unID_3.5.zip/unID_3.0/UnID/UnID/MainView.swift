//
//  MainView.swift
//  UnID
//
//  Created by Keegan Briskey on 7/6/21.
//

import SwiftUI

struct MainView: View {
    var body: some View {
        VStack(){
            Image("logo")
                .frame(width: 150.0, height: 50.0)
                .padding(.top, 80.0)
            
            Image(systemName: "person.circle")
                .foregroundColor(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0))
                .font(.system(size: 44))
                .padding(.leading, 270.0)
                .padding(.top, -130)
                .padding(.bottom, 40)
//            Spacer()
            
            //GENERAL INFORMATION BUTTON
            Button(action: {
                print("general information")
            }) {
                
                Text("General Information")
                    .font(.headline)
                    .foregroundColor(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0))
                    .multilineTextAlignment(.center)
                    .frame(width: 320.0, height: 50.0)
                    .overlay(
                        RoundedRectangle(cornerRadius: 5)
                            .stroke(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0), lineWidth: 2.5)
                    )
            }
            .padding(9.0)
            
            
            //PRESCRIPTIONS BUTTON
            NavigationLink(destination: prescriptView()){
                Text("Prescriptions")
                    .font(.headline)
                    .foregroundColor(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0))
                    .multilineTextAlignment(.center)
                    .frame(width: 320.0, height: 50.0)
                    .overlay(
                        RoundedRectangle(cornerRadius: 5)
                            .stroke(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0), lineWidth: 2.5)
                    )
            }
            .padding(/*@START_MENU_TOKEN@*/.all, 9.0/*@END_MENU_TOKEN@*/)
            
            //ALLERGIES BUTTON
            Button(action: {
                print("allergies")
            }) {
                
                Text("Allergies")
                    .font(.headline)
                    .foregroundColor(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0))
                    .multilineTextAlignment(.center)
                    .frame(width: 320.0, height: 50.0)
                    .overlay(
                        RoundedRectangle(cornerRadius: 5)
                            .stroke(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0), lineWidth: 2.5)
                    )
            }
            .padding(/*@START_MENU_TOKEN@*/.all, 9.0/*@END_MENU_TOKEN@*/)
            
            //VACCINATIONS BUTTON
            
            VStack {
                NavigationLink(destination: VaccinationMainView()) {
                    Text("Vaccinations")
                        .font(.headline)
                        .foregroundColor(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0))
                        .multilineTextAlignment(.center)
                        .frame(width: 320.0, height: 50.0)
                        .overlay(
                            RoundedRectangle(cornerRadius: 5)
                                .stroke(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0), lineWidth: 2.5)
                        )
                }
            }
            .padding(/*@START_MENU_TOKEN@*/.all, 9.0/*@END_MENU_TOKEN@*/)
            
            //SHARING BUTTON
            Button(action: {
                print("sharing")
            }) {
                
                NavigationLink(destination: SharingView()) {
                Text("Sharing")
                    .font(.headline)
                    .foregroundColor(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0))
                    .multilineTextAlignment(.center)
                    .frame(width: 320.0, height: 50.0)
                    .overlay(
                        RoundedRectangle(cornerRadius: 5)
                            .stroke(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0), lineWidth: 2.5)
                    )
                }
            }
            .padding(/*@START_MENU_TOKEN@*/.all, 9.0/*@END_MENU_TOKEN@*/)
            //BUTTONS END HERE
            Spacer()
            
            Image(systemName: "heart.text.square")
                .foregroundColor(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0))
                .font(.system(size: 44))
                .padding(.bottom, 40)
        }
        .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
        //}
        //START OF SCREEN 3
    }
}

struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MainView()
    }
}

