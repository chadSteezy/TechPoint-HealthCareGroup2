//
//  ContentView.swift
//  UnID
//
//  Created by Keegan Briskey on 7/2/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        //        NavigationView {
        
        VStack {
            
            Image("logo")
                .frame(width: 150.0, height: 100.0)
                .padding(.top, 50.0)
            
            Text("Sign In")
                .font(.largeTitle)
                .fontWeight(.regular)
                .padding(.top, 50.0)
                .padding(.bottom, 25.0)
            
            
            VStack {
                
                //input field for email
                HStack {
                    Image(systemName: "person.fill")
                        .padding(.leading, 7.0)
                    
                    
                    TextField("Email", text: /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Value@*/.constant("")/*@END_MENU_TOKEN@*/)
                        .foregroundColor(.blue)
                    
                }
                .frame(width: 300.0, height: 50.0)
                .overlay(
                    RoundedRectangle(cornerRadius: 7)
                        .stroke(Color.gray,
                                lineWidth: 2.5)
                )
                Spacer()
                
                //input field for password
                HStack {
                    Image(systemName: "key.fill")
                        .padding(.leading, 7.0)
                    
                    
                    TextField("Password", text: /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Value@*/.constant("")/*@END_MENU_TOKEN@*/)
                        .foregroundColor(.blue)
                    
                }
                .frame(width: 300.0, height: 50.0)
                .overlay(
                    RoundedRectangle(cornerRadius: 7)
                        .stroke(Color.gray,
                                lineWidth: 2.5)
                )
                Spacer()
                
            }//END OF NAVIGATION VIEW not really
            
            /*
             //BUTTON WITH LABEL VIEW (DOES NOT STAY)
             Button(action: {
             
             print("signing in")
             
             }, label: {
             Image(systemName: "person.crop.circle")
             Text("Sign In")
             
             })
             .padding(.all)
             .frame(width: 115.0, height: 50.0)
             .overlay(
             RoundedRectangle(cornerRadius: 5)
             .stroke(Color.blue, lineWidth: 2.5)
             )
             */
            //ATTEMPTED SIGN IN BUTTON
            Button(action: {
                print("Signing In")
            }) {
                Text("Sign In")
                    .font(.headline)
                    .foregroundColor(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0))
                    .multilineTextAlignment(.center)
                    .padding(.all)
                    .frame(width: 90.0, height: 50.0)
                    .overlay(
                        RoundedRectangle(cornerRadius: 5)
                            .stroke(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0), lineWidth: 2.5)
                    )
            }
            
            VStack(){
                Spacer()
                Text("Dont have an account?")
                
                //NEEDS TO BECOME A BUTTON AT SOME POINT
                NavigationLink(destination: Text("Sign In Page")) {
                    Text("Create one here")
                        .foregroundColor(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0))
                }
                Spacer()
            }
        }
        //        } //END OF NAVIGATION VIEW
        //START OF SCREEN 2
        
        //NavigationView {
        VStack(){
            Image("logo")
                .frame(width: 150.0, height: 50.0)
                .padding(.top, 30.0)
            Spacer()
            
            //GENERAL INFORMATION BUTTON
            Button(action: {
                print("general information")
            }) {
                
                Text("General Information")
                    .font(.headline)
                    .foregroundColor(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0))
                    .multilineTextAlignment(.center)
                    .frame(width: 320.0, height: 50.0)
                    .overlay(
                        RoundedRectangle(cornerRadius: 5)
                            .stroke(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0), lineWidth: 2.5)
                    )
            }
            .padding(9.0)
            
            
            //PRESCRIPTIONS BUTTON
            Button(action: {
                print("prescriptions")
            }) {
                
                Text("Prescriptions")
                    .font(.headline)
                    .foregroundColor(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0))
                    .multilineTextAlignment(.center)
                    .frame(width: 320.0, height: 50.0)
                    .overlay(
                        RoundedRectangle(cornerRadius: 5)
                            .stroke(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0), lineWidth: 2.5)
                    )
            }
            .padding(/*@START_MENU_TOKEN@*/.all, 9.0/*@END_MENU_TOKEN@*/)
            
            //ALLERGIES BUTTON
            Button(action: {
                print("allergies")
            }) {
                
                Text("Allergies")
                    .font(.headline)
                    .foregroundColor(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0))
                    .multilineTextAlignment(.center)
                    .frame(width: 320.0, height: 50.0)
                    .overlay(
                        RoundedRectangle(cornerRadius: 5)
                            .stroke(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0), lineWidth: 2.5)
                    )
            }
            .padding(/*@START_MENU_TOKEN@*/.all, 9.0/*@END_MENU_TOKEN@*/)
            
            //VACCINATIONS BUTTON
            Button(action: {
                print("vaccinations")
            }) {
                
                Text("Vaccinations")
                    .font(.headline)
                    .foregroundColor(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0))
                    .multilineTextAlignment(.center)
                    .frame(width: 320.0, height: 50.0)
                    .overlay(
                        RoundedRectangle(cornerRadius: 5)
                            .stroke(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0), lineWidth: 2.5)
                    )
            }
            .padding(/*@START_MENU_TOKEN@*/.all, 9.0/*@END_MENU_TOKEN@*/)
            
            //SHARING BUTTON
            Button(action: {
                print("sharing")
            }) {
                
                Text("Sharing")
                    .font(.headline)
                    .foregroundColor(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0))
                    .multilineTextAlignment(.center)
                    .frame(width: 320.0, height: 50.0)
                    .overlay(
                        RoundedRectangle(cornerRadius: 5)
                            .stroke(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0), lineWidth: 2.5)
                    )
            }
            .padding(/*@START_MENU_TOKEN@*/.all, 9.0/*@END_MENU_TOKEN@*/)
            //BUTTONS END HERE
            Spacer()
            
        }
        .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
        //}
        //START OF SCREEN 3
        //        NavigationView {
        VStack {
            
            HStack {
                Text("Vaccinations")
                    .font(.largeTitle)
                    .fontWeight(.semibold)
                    .padding(.trailing, 96.0)
                    .padding(.top, 30.0)
                    .frame(width: 375.0, height: 50.0)
                
                Image(systemName: "bandage")
                    .padding(.trailing, 300.0)
                    .padding(.top, 32.0)
                    .frame(width: 50.0, height: 50.0)
                    .imageScale(.large)
                
            }
            
            Text("Active")
                .font(.headline)
                .foregroundColor(Color.black)
                .padding(.trailing, 290.0)
                .padding(.top, 1.0)
            
            Text("Date Received")
                .padding(.leading, 250.0)
                .padding(.top, 5.0)
            
            
            //Spacer()
            
            //VACCINATION SLOT 1
            
            Button(action: {
                print("vaccination slot 1")
            }) {
                
                Text("COVID-19 (Pfizer)                      4/13/21")
                    .font(.title3)
                    .fontWeight(.medium)
                    .foregroundColor(Color.black)
                    .multilineTextAlignment(.center)
                    .frame(width: 350.0, height: 45.0)
                    .overlay(
                        RoundedRectangle(cornerRadius: 30)
                            .stroke(Color.gray, lineWidth: 2.0)
                    )
            }
            .padding([.top, .leading, .trailing], 1.0)
            .padding(.bottom, 9.0)
            
            //VACCINATION SLOT 2
            Button(action: {
                print("vaccination slot 2")
            }) {
                
                Text("FLUZONE (Sanofi)                     7/12/20")
                    .font(.title3)
                    .fontWeight(.medium)
                    .foregroundColor(Color.black)
                    .multilineTextAlignment(.center)
                    .frame(width: 350.0, height: 45.0)
                    .overlay(
                        RoundedRectangle(cornerRadius: 30)
                            .stroke(Color.gray, lineWidth: 2.0)
                    )
            }
            .padding(/*@START_MENU_TOKEN@*/.all, 9.0/*@END_MENU_TOKEN@*/)
            
            //VACCINATION SLOT 3
            Button(action: {
                print("vaccination slot 3")
            }) {
                
                Text("PCV13 (Prevnar)                       6/30/20")
                    .font(.title3)
                    .fontWeight(.medium)
                    .foregroundColor(Color.black)
                    .multilineTextAlignment(.center)
                    .frame(width: 350.0, height: 45.0)
                    .overlay(
                        RoundedRectangle(cornerRadius: 30)
                            .stroke(Color.gray, lineWidth: 2.0)
                    )
            }
            .padding(/*@START_MENU_TOKEN@*/.all, 9.0/*@END_MENU_TOKEN@*/)
            
            Divider()
            
            
            //INACTIVE VACCINATION SLOT 1
            
            VStack {
                Text("Need Renewal")
                    .font(.headline)
                    .foregroundColor(Color.black)
                    .padding(.trailing, 240.0)
                    .padding(.top, 1.0)
                
                Text("Date Received")
                    .padding(.leading, 250.0)
                    .padding(.top, 5.0)
            }
            
            Button(action: {
                print("inactive vaccination slot 1")
            }) {
                
                Text("TDAP (Tenivac)                          6/30/12")
                    .font(.title3)
                    .fontWeight(.medium)
                    .foregroundColor(Color.black)
                    .multilineTextAlignment(.center)
                    .frame(width: 350.0, height: 45.0)
                    .overlay(
                        RoundedRectangle(cornerRadius: 30)
                            .fill(Color.gray)
                    )
                    .padding(.top, 1)
                    .opacity(0.45)
            }
            Spacer()
            //        }
        } //LEADS TO NEXT PAGE
        
        
    }
    
    
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
        
    }
}
