//
//  VaxDetailView.swift
//  UnID
//
//  Created by Upasana Shrestha on 7/21/21.
//

import SwiftUI

struct VaccinationDetailView: View {
    
    @State var toggleIsOn1: Bool = true
    @State var toggleIsOn2: Bool = true
    @State var toggleIsOn3: Bool = false
    
    var body: some View {
        
        
        HStack {
            Text("COVID-19")
                .font(.largeTitle)
                .fontWeight(.semibold)
                .padding(.top, 0.0)
                .padding(.trailing, 215.0)
        }
        .padding(.top, -50.0)
        
        VStack(alignment:.leading, spacing:20) {
            // 1.
            
            GroupBox(label: Label("Dose 2",systemImage: "heart.fill")
                        .padding(.bottom, 2.0)
                        .font(.title)
            )
            {
                Text("Healthcare Professional/Clinic Site").font(.title2)
                    .foregroundColor(Color.gray)
                    .lineSpacing( 50 )
                Text("IUPUI-Lot: EW0153").font(.title3)
                    .offset(x: 0.0)
                Divider()
                
                Text("Administered").font(.title2).font(.headline)
                    .foregroundColor(Color.gray)
                Text("Pfizer 0.3ml").font(.title3)
                    .padding(.bottom, 2.0)
                
                Text("Date").font(.title2).font(.headline)
                    .foregroundColor(Color.gray)
                Text("05/04/21").font(.title3)
            }
            .padding(.top, -10.0)
            // 2.
            
            GroupBox(label: Label("Dose 1",systemImage: "heart.fill")
                        .padding(.bottom, 2.0)
                        .font(.title))
            {
                Text("Healthcare Professional/Clinic Site").font(.title2)
                    .foregroundColor(Color.gray)
                Text("IUPUI-Lot: EW0153").font(.title3)
                    .offset(x: 0.0)
                Divider()
                Text("Administered").font(.title2).font(.headline)
                    .foregroundColor(Color.gray)
                Text("Pfizer 0.3ml").font(.title3)
                    .padding(.bottom, 2.0)
                Text("Date").font(.title2).font(.headline)
                    .foregroundColor(Color.gray)
                Text("04/04/21").font(.title3)
            }
            .padding(.top, -15.0)
            Spacer()
        }
        
        VStack{
            Text("Sharing with:")
                .fontWeight(.semibold)
                .font(.title)
                .padding(.leading, -187)
            List{
                HStack{
                    Text("Community Health Network")
                    Toggle(isOn: $toggleIsOn1){
                    }
                }
                HStack{
                    Text("IUPUI")
                    Toggle(isOn: $toggleIsOn2){
                        
                    }
                }
            }
            .padding(.top, -1.0)
        }
        .padding(.top, -21)
    }
}

struct VaccinationDetail_Previews: PreviewProvider {
    static var previews: some View {
        VaccinationDetailView()
    }
}

