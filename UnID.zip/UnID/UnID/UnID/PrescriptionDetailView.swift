//
//  PrescriptionDetailView.swift
//  UnID
//
//  Created by Keegan Briskey on 7/28/21.
//

import SwiftUI

struct PrescriptionDetailView: View {
    
    @State var toggleState1: Bool = true
    @State var toggleState2: Bool = true
    @State var toggleState3: Bool = true
    
    var body: some View {
            
            VStack {
                Text("(Tylenol)")
                    .font(.headline)
                    .fontWeight(.light)
                    .navigationTitle("Acetaminophen")
                    .padding(.trailing, 298.0)
                    .padding(.top, -115.0)

                VStack {
                    HStack {
                        Text("Refill Date")
                            .font(.headline)
                            .fontWeight(.bold)
                            .foregroundColor(Color.gray)
                            .padding(.trailing, 30.0)
                        Text("Remaining")
                            .font(.headline)
                            .fontWeight(.bold)
                            .foregroundColor(Color.gray)
                            .padding(.trailing, 30.0)
                        Text("Dosage")
                            .font(.headline)
                            .fontWeight(.bold)
                            .foregroundColor(Color.gray)
                    }
                    HStack {
                        Text("07/01")
                            .fontWeight(.semibold)
                            .padding(.leading, 22.0)
                        Text("4")
                            .fontWeight(.semibold)
                            .padding(.leading, 80.0)
                        Text("100mg")
                            .fontWeight(.semibold)
                            .padding(.leading, 75.0)
                    }
                }
                .padding(.top, -85.0)
                Divider()
                    .padding(.top, -30.0)
                
                HStack {
                    NavigationLink(destination: RefillView()) {
                    Text("Request Refill")
                        .font(.title3)
                        .fontWeight(.medium)
                        .frame(width: 130.0, height: 20.0)
                        .foregroundColor(.black)
                }
                .padding(.all, 13.0)
                .overlay(
                    RoundedRectangle(cornerRadius: 30)
                        .stroke(Color.gray)
                )
                .padding(.top, -15.0)
                .padding(.bottom, 15.0)
                }
                
                VStack {
                    Text("Description")
                        .font(.title2)
                        .fontWeight(.bold)
                        .padding(.leading, -182.0)
                        .padding(.bottom, 0.1)
                    
                    Text("Tylenol (acetaminophen) is an analgesic (pain reliever) and antipyretic (fever reducer) used for treating pain and fever associated with many conditions. Tylenol is available in generic form and over-the-counter (OTC).")
                        .padding(.horizontal, 13.0)
                }
                Divider()
                    .padding(.top, 10.0)
                    .padding(.bottom, 10.0)
                
                HStack {
                    Image(systemName: "person.crop.circle")
                        .font(.system(size: 35))
                        .foregroundColor(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0))
                    
                    Text("Sharing")
                        .font(.title)
                        .fontWeight(.semibold)
                        .foregroundColor(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0))
                        .padding(.leading, -5.0)
                }
                .padding(.leading, -185.0)

                
                VStack {
                    HStack {
                        Text("Community Health Network")
                            .fontWeight(.semibold)
                        Toggle(isOn: $toggleState1) {
                        }
                    }
                    HStack {
                        Text("IUPUI")
                            .fontWeight(.semibold)
                        Toggle(isOn: $toggleState2) {
                        }
                    }
                    HStack {
                        Text("Indianapolis MedCheck")
                            .fontWeight(.semibold)
                        Toggle(isOn: $toggleState3) {
                        }
                    }
                }
                .padding(.horizontal, 12.0)
            }
        }
    }

struct PrescriptionDetailView_Previews: PreviewProvider {
    static var previews: some View {
        PrescriptionDetailView()
    }
}
