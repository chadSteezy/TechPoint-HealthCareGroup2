//
//  PrescriptionView.swift
//  UnID
//
//  Created by Keegan Briskey on 7/28/21.
//

import SwiftUI

struct PrescriptionView: View {
    var body: some View {
        
        VStack {
            Text("Active Prescriptions")
                .font(.headline)
                .padding(.leading, -179.0)
                .padding(.top, -9.0)
                .foregroundColor(Color(red: 0.254, green: 0.329, blue: 0.996, opacity: 1.0))
            
            HStack {
                Text("Remaining")
            }
            .padding(.bottom, 3.0)
            .padding(.leading, 265.0)
            
            VStack {
                
                //button 1
                HStack {
                    NavigationLink(destination: PrescriptionDetailView()) {
                        Text("Acetaminophen")
                            .font(.title2)
                            .fontWeight(.medium)
                            .padding(.leading, -80.0)
                            .frame(width: 260.0, height: 50.0)
                            .overlay(
                                RoundedRectangle(cornerRadius: 30)
                                    .stroke(Color.gray)
                            )
                            .foregroundColor(.black)
                    }
                    
                    //read 1
                    HStack {
                        Text("14")
                            .font(.title2)
                            .fontWeight(.medium)
                        Image(systemName: "pills")
                            .font(.system(size: 22))
                    }
                    .frame(width: 100.0, height: 50.0)
                    .overlay(
                        RoundedRectangle(cornerRadius: 30)
                            .stroke(Color.gray)
                    )
                }
                .padding(.bottom, 9.0)
                
                //button 2
                HStack {
                    Text("Amoxicillin")
                        .font(.title2)
                        .fontWeight(.medium)
                        .padding(.leading, -120.0)
                        .frame(width: 260.0, height: 50.0)
                        .overlay(
                            RoundedRectangle(cornerRadius: 30)
                                .stroke(Color.gray)
                        )
                    //read 2
                    HStack {
                        Text("16")
                            .font(.title2)
                            .fontWeight(.medium)
                        Image(systemName: "pills")
                            .font(.system(size: 22))
                    }
                    .frame(width: 100.0, height: 50.0)
                    .overlay(
                        RoundedRectangle(cornerRadius: 30)
                            .stroke(Color.gray)
                    )
                }
                .padding(.bottom, 9.0)
                
                //button 3
                HStack {
                    Text("Atorvastatin")
                        .font(.title2)
                        .fontWeight(.medium)
                        .padding(.leading, -120.0)
                        .frame(width: 260.0, height: 50.0)
                        .overlay(
                            RoundedRectangle(cornerRadius: 30)
                                .stroke(Color.gray)
                        )
                    //read 3
                    HStack {
                        Text("2 ")
                            .font(.title2)
                            .fontWeight(.medium)
                            .foregroundColor(.red)
                        Image(systemName: "pills")
                            .font(.system(size: 22))
                    }
                    .frame(width: 100.0, height: 50.0)
                    .overlay(
                        RoundedRectangle(cornerRadius: 30)
                            .stroke(Color.gray)
                    )
                }
                .padding(.bottom, 9.0)
                
                //button 4
                HStack {
                    Text("Ciprofloxacin")
                        .font(.title2)
                        .fontWeight(.medium)
                        .padding(.leading, -110.0)
                        .frame(width: 260.0, height: 50.0)
                        .overlay(
                            RoundedRectangle(cornerRadius: 30)
                                .stroke(Color.gray)
                        )
                    //read 4
                    HStack {
                        Text("19")
                            .font(.title2)
                            .fontWeight(.medium)
                        Image(systemName: "pills")
                            .font(.system(size: 22))
                    }
                    .frame(width: 100.0, height: 50.0)
                    .overlay(
                        RoundedRectangle(cornerRadius: 30)
                            .stroke(Color.gray)
                    )
                }
                .padding(.bottom, 9.0)
            }
            Divider()
            
            VStack {
                Text("Inactive Prescriptions")
                    .font(.headline)
                    .padding(.leading, -179.0)
                    .padding(.bottom, 3.0)
                
                HStack {
                    Text("Remaining")
                }
                .padding(.bottom, 3.0)
                .padding(.leading, 265.0)
                
                HStack {
                    Text("NAFCILLIN")
                        .font(.title2)
                        .fontWeight(.medium)
                        .padding(.leading, -120.0)
                        .frame(width: 260.0, height: 50.0)
                        .overlay(
                            RoundedRectangle(cornerRadius: 30)
                                .stroke(Color.gray)
                        )
                    HStack {
                        Text("--")
                            .font(.title2)
                            .fontWeight(.medium)
                        Image(systemName: "pills")
                            .font(.system(size: 22))
                    }
                    .frame(width: 100.0, height: 50.0)
                    .overlay(
                        RoundedRectangle(cornerRadius: 30)
                            .stroke(Color.gray)
                    )
                }
                .padding(.bottom, 9.0)
                
                //button 2
                HStack {
                    Text("QOLIANA")
                        .font(.title2)
                        .fontWeight(.medium)
                        .padding(.leading, -120.0)
                        .frame(width: 260.0, height: 50.0)
                        .overlay(
                            RoundedRectangle(cornerRadius: 30)
                                .stroke(Color.gray)
                        )
                    //read 2
                    HStack {
                        Text("--")
                            .font(.title2)
                            .fontWeight(.medium)
                        Image(systemName: "pills")
                            .font(.system(size: 22))
                    }
                    .frame(width: 100.0, height: 50.0)
                    .overlay(
                        RoundedRectangle(cornerRadius: 30)
                            .stroke(Color.gray)
                    )
                }
                .padding(.bottom, 9.0)
            }
            Spacer()
        }
        .navigationTitle("Prescriptions")
    }
}

struct PrescriptionView_Previews: PreviewProvider {
    static var previews: some View {
        PrescriptionView()
    }
}
