//
//  RefillView.swift
//  UnID
//
//  Created by Keegan Briskey on 7/29/21.
//

import SwiftUI

struct RefillView: View {
    
    @State var toggleState1: Bool = true
    
    var body: some View {
        VStack {
            Text("Tylenol")
                .padding(.top, -255.0)
                .padding(.leading, -178.0)
            
            VStack(alignment: .leading) {
                Text("Prescribed by: Dr. Grace Booth")
                    .font(.headline)
                    .foregroundColor(Color.gray)
                    .padding(.bottom, 1.0)
                Text("Last Ordered: 06/01")
                    .font(.headline)
                    .foregroundColor(Color.gray)
                    .padding(.bottom, 1.0)
                Text("Quantity: 30")
                    .font(.headline)
                    .foregroundColor(Color.gray)
            }
            .padding(.leading, -110.0)
            .padding(.top, -220.0)
            
            HStack {
                Text("Request Refill")
                    .font(.title3)
                    .fontWeight(.medium)
                    .frame(width: 130.0, height: 20.0)
                    .foregroundColor(.black)
            }
            .padding(.all, 13.0)
            .overlay(
                RoundedRectangle(cornerRadius: 30)
                    .stroke(Color.gray)
            )
            .padding(.top, -100.0)
            Text("Refills Remaining: 1")
                .padding(.top, -55.0)
            
            Divider()
                .padding(.bottom, 9.0)
            
            Text("Manage Refill")
                .font(.title2)
                .fontWeight(.bold)
                .padding(.leading, -183.0)
            HStack {
                Text("Auto-Refill")
                    .font(.title3)
                    .fontWeight(.regular)
                Toggle(isOn: $toggleState1) {
                }
            }
            .padding(.horizontal, 13.0)
            .padding(.bottom, 9.0)
            
            HStack {
                Text("Change Refill Date")
                    .font(.title3)
                    .fontWeight(.regular)
                    .padding(.trailing, 160.0)
                Image(systemName: "calendar")
                    .font(.system(size: 30))
            }
            
        }
        .navigationTitle("Refills")
    }
}

struct RefillView_Previews: PreviewProvider {
    static var previews: some View {
        RefillView()
    }
}

