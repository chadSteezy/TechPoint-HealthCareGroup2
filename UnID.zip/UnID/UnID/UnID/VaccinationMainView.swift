//
//  VaccinationMainView.swift
//  UnID
//
//  Created by Keegan Briskey on 7/6/21.
//

import SwiftUI

struct VaccinationMainView: View {
    var body: some View {
        VStack {
            HStack {
                Text("Vaccinations")
                    .font(.largeTitle)
                    .fontWeight(.semibold)
                    .padding(.trailing, 158.0)
                    .padding(.top, -80.0)
                    .frame(width: 375.0, height: 50.0)
                
            }
            Text("Active")
                .font(.headline)
                .foregroundColor(Color.black)
                .padding(.trailing, 295.0)
                .padding(.top, -75.0)
                .padding(.bottom, 20.0)
            
            
            HStack {
            Text("Date Received")
                .padding(.leading, 250.0)
                .padding(.top, -80.0)
            }
            
            //VACCINATION SLOT 1
            VStack {
                NavigationLink(destination: VaccinationDetailView().navigationBarHidden(false)) {
                    Text("COVID-19 (Pfizer)                       7/11/20")
                        .font(.title3)
                        .fontWeight(.medium)
                        .padding(.leading, 0.0)
                        .foregroundColor(Color.black)
                        .multilineTextAlignment(.center)
                        .frame(width: 350.0, height: 45.0)
                        .overlay(
                            RoundedRectangle(cornerRadius: 30)
                                .stroke(Color.gray, lineWidth: 2.0)
                        )
                        
                        .padding(.top, -44.0)
                }                .padding(.bottom, 9.0)
                
            }
            
            //VACCINATION SLOT 2
            Button(action: {
                print("vaccination slot 2")
            }) {
                
                Text("FLUZONE (Sanofi)                     7/12/20")
                    .font(.title3)
                    .fontWeight(.medium)
                    .foregroundColor(Color.black)
                    .multilineTextAlignment(.center)
                    .frame(width: 350.0, height: 45.0)
                    .overlay(
                        RoundedRectangle(cornerRadius: 30)
                            .stroke(Color.gray, lineWidth: 2.0)
                    )
            }
            .padding(.all, 4.0)
            
            //VACCINATION SLOT 3
            Button(action: {
                print("vaccination slot 3")
            }) {
                
                Text("PCV13 (Prevnar)                       6/30/20")
                    .font(.title3)
                    .fontWeight(.medium)
                    .foregroundColor(Color.black)
                    .multilineTextAlignment(.center)
                    .frame(width: 350.0, height: 45.0)
                    .overlay(
                        RoundedRectangle(cornerRadius: 30)
                            .stroke(Color.gray, lineWidth: 2.0)
                    )
            }
            .padding(/*@START_MENU_TOKEN@*/.all, 9.0/*@END_MENU_TOKEN@*/)
            
            
            
            //INACTIVE VACCINATION SLOT 1
            
            VStack {
                Text("Need Renewal")
                    .font(.headline)
                    .foregroundColor(Color.black)
                    .padding(.trailing, 240.0)
                    .padding(.top, 1.0)
                
                
                
                Button(action: {
                    print("inactive vaccination slot 1")
                }) {
                    
                    Text("TDAP (Tenivac)                          6/30/12")
                        .font(.title3)
                        .fontWeight(.medium)
                        .foregroundColor(Color.black)
                        .multilineTextAlignment(.center)
                        .frame(width: 350.0, height: 45.0)
                        .overlay(
                            RoundedRectangle(cornerRadius: 30)
                                .fill(Color.gray)
                        )
                        .padding(.top, 1)
                        .opacity(0.45)
                }
            }
            .padding(.bottom, 350.0)
        }
    }
    
    struct VaccinationMainView_Previews: PreviewProvider {
        static var previews: some View {
            VaccinationMainView()
        }
    }
}
